class TemplateType < ActiveRecord::Base
        
    include Resistor::TemplateType
    
end
