class SystemCc < ActiveRecord::Base
end
