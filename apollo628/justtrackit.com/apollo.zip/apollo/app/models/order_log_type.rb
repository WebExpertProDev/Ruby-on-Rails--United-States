class OrderLogType < ActiveRecord::Base
    
end
