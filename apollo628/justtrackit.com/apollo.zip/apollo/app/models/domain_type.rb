class DomainType < ActiveRecord::Base

    belongs_to :domain

end
