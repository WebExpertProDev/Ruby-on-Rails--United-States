class Template < ActiveRecord::Base
                                       
    include Resistor::Template
    
end
