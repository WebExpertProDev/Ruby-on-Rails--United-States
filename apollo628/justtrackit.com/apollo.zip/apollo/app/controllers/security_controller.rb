class SecurityController < ApplicationController
end
