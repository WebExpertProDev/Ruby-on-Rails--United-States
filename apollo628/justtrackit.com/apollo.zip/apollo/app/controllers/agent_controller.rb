class AgentController < ApplicationController
end
