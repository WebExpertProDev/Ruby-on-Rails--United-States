###
# @class User
# Application user object
# manages authentication and holds a valid Account object in @account when user is logged in
#
class User < Resistor::User
    
end
