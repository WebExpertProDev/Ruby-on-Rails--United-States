class AddOrderTypeField < ActiveRecord::Migration
    
end
