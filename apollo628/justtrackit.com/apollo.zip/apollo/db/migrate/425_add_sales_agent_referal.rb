class AddSalesAgentReferal < ActiveRecord::Migration
  def self.up
      #d = Domain.find_by_name('sales_agency')
      
      #if (d.fields.find_by_name('referer'))
      #    DomainField.create(
      ##      :domain_id => d.id,
       ##     :name => 'referer',
        ##    :label => "Referred by",
         #   :config => {},
        #    :field_type => 'RExt.form.ComboBoxAdd',
        #    :required => false
        #  )
      #end
            
  end

  def self.down
  end
end
